import React, { useEffect, useState } from "react";
import ModuleLayout from "/src/layouts/ModuleLayout";
import { api } from "/src/api";
import { fmt } from "/src/Collection/utils/formatters";

export default function LaporanCancel() {

  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);

      // RESMI — sumber data cancel:
      // 1. Cancel dari CashIn
      // 2. Cancel dari Tukar Kwitansi

      const res1 = await api.kasir.get("/cashinCancel");
      const cashInCancel = res1.data || [];

      const res2 = await api.kasir.get("/tukarkwiCancel");
      const tukarCancel = res2.data || [];

      // Gabungkan
      const merged = [...cashInCancel, ...tukarCancel];

      setRows(merged);
    } catch (err) {
      console.error("Gagal load cancel:", err);
      setRows([]);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="p-6 text-center">Memuat data...</div>;

  return (
    <ModuleLayout>
      <div className="p-6">

        <h2 className="text-2xl font-black mb-4">LAPORAN CANCEL</h2>

        <div className="bb-table-wrapper">

          <table className="bb-table w-full text-sm">
            <thead>
              <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Label Tgl</th>
                <th>No Kwitansi</th>
                <th>Nama</th>
                <th>Nilai</th>
                <th>Jenis Trx</th>
                <th>Keterangan</th>
                <th>Admin</th>
              </tr>
            </thead>

            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan="9" className="text-center py-3 text-gray-500">
                    Tidak ada data cancel.
                  </td>
                </tr>
              ) : (
                rows.map((r, i) => (
                  <tr key={i}>
                    <td>{i + 1}</td>
                    <td>{r.tglKwi}</td>
                    <td>{r.lblTgl || "-"}</td>
                    <td>{r.noKwi}</td>
                    <td>{r.namaKons}</td>
                    <td>Rp {fmt(r.nilaiRp)}</td>
                    <td>{r.jnsTrx}</td>
                    <td>{r.tKet || "-"}</td>
                    <td>{r.adminlog}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

        </div>
      </div>
    </ModuleLayout>
  );
}